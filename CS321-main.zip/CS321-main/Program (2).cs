﻿using System;

class Program
{
    static void Main()
    {
        Console.WriteLine(CreateEmail("Rex", "Max"));
        Console.WriteLine(CreateEmail("Joe", "Frost"));
        Console.WriteLine(CreateEmail("Joce", "Ron"));

        Console.ReadLine();
    }

    static string CreateEmail(string firstName, string lastName)
    {
        string email = firstName[0].ToString().ToLower() +
                       lastName.Substring(0, Math.Min(3, lastName.Length)).ToLower() +
                       "@abc.com";
        return email;
    }
}

