﻿using System;

namespace AccountTest
{
    public class Account
    {
        public string AccountHolderName { get; set; }
        public decimal Balance { get; private set; }

        public Account(string name, decimal initialBalance)
        {
            AccountHolderName = name;
            Balance = initialBalance;
        }

        public virtual void Deposit(decimal amount)
        {
            Balance += amount;
            Console.WriteLine($"{amount} deposited. New balance: {Balance}");
        }

        public virtual bool Withdraw(decimal amount)
        {
            if (amount <= Balance)
            {
                Balance -= amount;
                Console.WriteLine($"{amount} withdrawn. The remaining balance: {Balance}");
                return true;
            }
            Console.WriteLine("Insufficient funds!");
            return false;
        }
    }

    public class Checking : Account
    {
        public Checking(string name, decimal initialBalance) : base(name, initialBalance) { }
    }

    public class Saving : Account
    {
        public decimal InterestRate { get; private set; }

        public Saving(string name, decimal initialBalance, decimal interestRate)
            : base(name, initialBalance)
        {
            InterestRate = interestRate;
        }

        public void ApplyInterest()
        {
            var interest = Balance * InterestRate / 100;
            Deposit(interest);
            Console.WriteLine($"Interest applied: {interest}");
        }
    }

    public class JointSaving : Saving
    {
        public string SecondAccountHolder { get; private set; }

        public JointSaving(string name, string secondName, decimal initialBalance, decimal interestRate)
            : base(name, initialBalance, interestRate)
        {
            SecondAccountHolder = secondName;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Checking checkingAccount = new Checking("John Doe", 1000);
            checkingAccount.Deposit(200);
            checkingAccount.Withdraw(500);

            Saving savingAccount = new Saving("Jane Doe", 1500, 3.5m);
            savingAccount.Deposit(300);
            savingAccount.ApplyInterest();

            JointSaving jointAccount = new JointSaving("Alice", "Bob", 2000, 4.0m);
            jointAccount.ApplyInterest();
            Console.WriteLine($"Joint account holders: {jointAccount.AccountHolderName} and {jointAccount.SecondAccountHolder}");
        }
    }
}
