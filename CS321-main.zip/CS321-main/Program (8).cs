﻿using System;

class Program
{
    static void Main()
    {
        DateTime birthday = new DateTime(1865, 7, 25);
        Console.WriteLine("Year: " + birthday.Year);
        Console.WriteLine("Month: " + birthday.Month);
        Console.WriteLine("Day: " + birthday.Day);
        Console.WriteLine("Day of the Week: " + birthday.DayOfWeek);
        Console.WriteLine("Long Date Format: " + birthday.ToLongDateString());

        Console.ReadLine();
    }
}
