﻿
using System;

namespace RoadLineSimulation
{
    class Program
    {
        static void Main(string[] args)
        {
            DisplayRoadLine();
        }

        // ------------------------------------------------
        // Function Name: DisplayRoadLine()
        // Input Argument: None
        // Summary: Continuously displays a vertical line in the console window, simulating
        // a steady roadside marker. Each segment of the line is printed on a new line,
        // with a short delay between segments to mimic continuous movement or real-time
        // roadside appearance.
        /*
            The first challenging that we experienced while doing this was uploading the zip file into our GitHub Code space,
            but after some time, we were able to complete it, 
            and our next step is to form the road for the game. We opted to modify the color, as 
            well as the value "x" from the previous code. We'd modified it to "|". 
            We also attempted to understand each idea of the function offered. 
            For what is offered, we now have an outline for our project. 
            We want to be more creative with this program in order to meet its standards. 
*/
        // ------------------------------------------------
        static void DisplayRoadLine()
        {
            // Loop to continuously print the line indefinitely
            while (true)
            {
                // Prints the vertical line symbol representing one side of the road
                Console.WriteLine("     |");

                // Pauses briefly between each line segment to simulate continuous output
                System.Threading.Thread.Sleep(200); // Waits 200 milliseconds
            }
        }
    }
}
/*
//TPO1
//Victoria Roman, Shereyas Chitneni
//Atuopilot zip.file
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//What was provided
namespace ProjectTest
{
   class Program
    {
        static private int w = 55; 
        static private int h = 30;
        static private char[,] display;
        static private Random random = new Random();
        static void Main(string[] args)//Sets the console
        {
            Console.ForegroundColor = ConsoleColor.Blue;//Changed the color
            while(true)
            {
                ready();//displays grid
                go();
        
                Console.WriteLine("Press Enter to start");
                //  I want to changed it to a asking user to start game
                Console.ReadLine();


            }
        }

        static void ready()
        {
            display = new char[h, w];
            for (int i = 0; i < h; i++)
            {
                int loc = random.Next(0, 10);
                for (int j = 0; j < w; j++)
                {
                    if (j == loc)
                    {
                        display[i, j] = '|';//Changed from "X" to "|"
                    }
                }
            }

        }       
        static void go()
        {
            StringBuilder paintAll = new StringBuilder(w * h);
            for (int i = 0; i < h; i++)
            {
                for (int j = 0; j < w; j++)
                {
                    paintAll.Append(display[i, j]);
                }
                paintAll.AppendLine();
            }
            Console.SetCursorPosition(0, 0);
            Console.Write(paintAll);
            Console.WriteLine("Hit enter to update the next line...");
        }
    }
}
*/
