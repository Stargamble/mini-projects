﻿// TPO2
//Victoria Roman, Dane Wahl, Luis Rodriguez, Shreyas Chitneni, Krystal Salinas
//Atuopilot zip.file
using System;
using System.Text;

namespace ProjectTest
{
    class Program
    {
        static private int width = 30;
        static private int height = 20;
        static private char[,] display;
        static private Random random = new Random();
        static private int carPosition; // Track car's horizontal position
        static private List<Obstacle> obstacles = new List<Obstacle>();
        static private int level = 1; // Track the current level

        static void Main(string[] args)
        {
            carPosition = width / 2; // Initial car position in the center

            while (true)
            {
                Console.Clear();
                Console.WriteLine($"Welcome to Level {level}!");

                PlayLevel();

                // Advance to the next level
                level++;
                width += 10; // Increase road width for added difficulty
                if (width > 100) width = 100; // Limit max width
            }
        }

        static void PlayLevel()
        { // Create obstacles
            obstacles.Clear(); 
            GenerateObstacles(); 

            while (true)
            {
                ready();
                UpdateObstacles(); // Move obstacles
                CheckCollision(); // Check for collisions
                go();

                Console.WriteLine(" Press enter to proceed to the next frame. Use 'a' to move left, 'd' to move right, ");
                var key = Console.ReadKey(true); // Read user input

                // Update car position based on input
                if (key.Key == ConsoleKey.A && carPosition > 1)
                {
                    carPosition--; // Move car left
                }
                else if (key.Key == ConsoleKey.D && carPosition < width - 2)
                {
                    carPosition++; // Move car right
                }
                else if (key.Key == ConsoleKey.Enter)
                {
                    // Continue game frame
                }

                // Check for "level completed" condition
                if (obstacles.Count == 0) // All obstacles cleared
                {
                    Console.WriteLine($"You've completed Level {level}!");
                    Console.WriteLine("Press Enter to continue...");
                    Console.ReadLine();
                    break;
                }
            }
        }

        static void GenerateObstacles()
        {
            for (int i = 0; i < level * 3; i++) 
            {
                int x = random.Next(1, width - 1); // Random horizontal position
                int y = random.Next(1, height / 2); // Random vertical position 
                obstacles.Add(new Obstacle(x, y));
            }
        }

        static void UpdateObstacles()
        {
            for (int i = obstacles.Count - 1; i >= 0; i--) // 
            {
                var obstacle = obstacles[i];
                obstacle.Y++; 

                // Remove obstacle if it goes off the screen
                if (obstacle.Y >= height)
                {
                    obstacles.RemoveAt(i);
                }
            }
        }

        static void CheckCollision()
        {
            foreach (var obstacle in obstacles)
            {
                if (obstacle.Y == height - 1 && obstacle.X == carPosition) 
                {
                    Console.Clear();
                    Console.WriteLine("Game Over! You hit an obstacle!");
                    Environment.Exit(0); // Used to end the game
                }
            }
        }

        static void ready()
        {
            display = new char[height, width];
            for (int i = 0; i < height; i++)
            {
                for (int j = 0; j < width; j++)
                {
                    display[i, j] = ' ';
                }
            }

            for (int i = 0; i < height; i++)
            {
                display[i, 0] = '|'; // Left road shoulder
                display[i, width - 1] = '|'; // Right road shoulder
            }

            // Place the car at the updated position
            display[height - 1, carPosition] = 'o';

            // Add obstacles to on the road
            foreach (var obstacle in obstacles)
            {
                if (obstacle.Y >= 0 && obstacle.Y < height)
                {
                    display[obstacle.Y, obstacle.X] = obstacle.Symbol;
                }
            }
        }

        static void go()
        {
            StringBuilder paintAll = new StringBuilder(width * height);
            for (int i = 0; i < height; i++)
            {
                for (int j = 0; j < width; j++)
                {
                    paintAll.Append(display[i, j]);
                }
                paintAll.AppendLine();
            }
            Console.SetCursorPosition(0, 0);
            Console.Write(paintAll);
        }
    }

    class Obstacle
    {
        public int X { get; set; }
        public int Y { get; set; }
        public char Symbol { get; set; } = 'X';

        public Obstacle(int x, int y)
        {
            X = x;
            Y = y;
        }
    }
}
