﻿using System;

namespace CityTest
{
    public class City
    {
    
        private string name;
        private int population;

        
        public City(string name, int population)
        {
            this.name = name;
            this.population = population;
        }

        
        public string GetCity()
        {
            return name;
        }

        
        public int GetPopulation()
        {
            return population;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            
            City myCity = new City("Seattle", 750000);

            
            Console.WriteLine($"City: {myCity.GetCity()}");
            Console.WriteLine($"Population: {myCity.GetPopulation()}");
        }
    }
}


