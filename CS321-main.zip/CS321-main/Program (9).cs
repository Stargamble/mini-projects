﻿// See https://aka.ms/new-console-template for more information
using System;

public class AccountTest
{
    private decimal balance;
    public string AccountHolderName { get; set; }

    public BankAccount(string name, decimal initialBalance)
    {
        AccountHolderName = name;
        balance = initialBalance;
    }

    public void Deposit(decimal amount)
    {
        if (amount > 0)
        {
            balance += amount;
            Console.WriteLine($"Deposited ${amount}. New balance: ${balance}");
        }
        else
        {
            Console.WriteLine("Deposit amount must be positive.");
        }
    }

    public bool Withdraw(decimal amount)
    {
        if (amount <= balance && amount > 0)
        {
            balance -= amount;
            Console.WriteLine($"Withdrew ${amount}. New balance: ${balance}");
            return true;
        }
        else
        {
            Console.WriteLine("Insufficient balance or invalid amount.");
            return false;
        }
    }

    public decimal GetBalance()
    {
        return balance;
    }
}

class Program
{
    static void Main(string[] arg)
    {
        BankAccount myAccount = new BankAccount("John Doe", 1000);
        Console.WriteLine($"Account for {myAccount.AccountHolderName} opened with balance of ${myAccount.GetBalance()}");
        myAccount.Deposit(500);
        myAccount.Withdraw(200);
        myAccount.Withdraw(20000);
        Console.WriteLine($"Final balance: ${myAccount.GetBalance()}.");
    }
}
