using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoPilot
{
   class Program
    {
        static private int w = 55; 
        static private int h = 30;
        static private char[,] display;
        static private Random random = new Random();
        static void Main(string[] args)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            while(true)
            {
                ready();
                go();
                Console.Read(); // hit enter to execute the next iteration.
            }
        }
        static void ready()
        {
            display = new char[h, w];
            for (int i = 0; i < h; i++)
            {
                int loc = random.Next(0, 10);
                for (int j = 0; j < w; j++)
                {
                    if (j == loc)
                    {
                        display[i, j] = 'X';
                    }
                }
            }
        }       
        static void go()
        {
            StringBuilder paintAll = new StringBuilder(w * h);
            for (int i = 0; i < h; i++)
            {
                for (int j = 0; j < w; j++)
                {
                    paintAll.Append(display[i, j]);
                }
                paintAll.AppendLine();
            }
            Console.SetCursorPosition(0, 0);
            Console.Write(paintAll);
            Console.WriteLine("Hit enter to update the next line...");
        }
    }

