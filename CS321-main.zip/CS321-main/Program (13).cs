using System;

public class BankAccount
{
    private decimal balance;

    public string AccountHolderName { get; set; }

    public BankAccount(string name, decimal initialBalance)
    {
        AccountHolderName = name;
        balance = initialBalance;
    }

    public decimal GetBalance()
    {
        return balance;
    }

    protected void UpdateBalance(decimal amount)
    {
        balance += amount;
    }

    public void Deposit(decimal amount)
    {
        if (amount > 0)
        {
            balance += amount;
            Console.WriteLine($"Deposited ${amount}. New balance: ${balance}");
        }
        else
        {
            Console.WriteLine("Deposit amount must be positive.");
        }
    }
}

public class SavingsAccount : BankAccount
{
    public decimal InterestRate { get; private set; }

    public SavingsAccount(string name, decimal initialBalance, decimal interestRate)
        : base(name, initialBalance)
    {
        InterestRate = interestRate;
    }

    public void ApplyInterest()
    {
        decimal interest = GetBalance() * InterestRate / 100;
        UpdateBalance(interest);
        Console.WriteLine($"Interest applied: ${interest}. New balance: ${GetBalance()}");
    }
}

class Program
{
    static void Main(string[] args)
    {
        SavingsAccount mySavings = new SavingsAccount("Jane Doe", 1000, 5);
        Console.WriteLine($"Savings account for {mySavings.AccountHolderName} opened with balance of ${mySavings.GetBalance()} and an interest rate of {mySavings.InterestRate}%.");

        mySavings.Deposit(500);
        mySavings.ApplyInterest();

        Console.WriteLine($"Final balance: ${mySavings.GetBalance()}.");
    }
}
