﻿// TPO2
//Victoria Roman, Dane Wahl, Luis Rodriguez, Shreyas Chitneni, Krystal Salinas
//Atuopilot zip.file
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.ExceptionServices;
using System.Text;
using System.Threading.Tasks;
//What was provided
namespace ProjectTest
{
    class Program
    {
        static private int width = 55;
        static private int height = 30;
        static private char[,] display;
        static private Random random = new Random();
        static void Main(string[] args)//Sets the console
        {
            Console.ForegroundColor = ConsoleColor.Blue;//Changed the color
            while (true)
            {
                ready();//displays grid
                go();

                Console.WriteLine("Press Enter to start");
                //  I want to changed it to a asking user to start game
                Console.ReadLine();


            }
        }

        static void ready()
        { // Initilizes road with a straight lines as both left and right shoulder of the road with a 'o' as a car in the center 
            display = new char[height, width];
            for (int i = 0; i < height; i++)// loop through all rows to the given height
            {
                for (int j = 0; j < width; j++) // loop through all columns to the given width
                {
                    display[i, j] = ' '; 
                }

            }
            for (int i = 0; i < height; i++)
            {
                display[i, 0] = '|'; // displays left road shoulder
                if (width>54)
                {
                    display[i, 54] = '|'; // displays right road shoulder
                }

                int car = width / 2; // placing car in center 
                display[height - 1, car] = 'o'; // displays car on lowest row only
            }
        }
        static void go()
        {
            StringBuilder paintAll = new StringBuilder(width * height);
            for (int i = 0; i < height; i++)
            {
                for (int j = 0; j < width; j++)
                {
                    paintAll.Append(display[i, j]);
                }
                paintAll.AppendLine();
            }
            Console.SetCursorPosition(0, 0);
            Console.Write(paintAll);
            Console.WriteLine("Hit enter to update the next line...");
        }
    }
}
