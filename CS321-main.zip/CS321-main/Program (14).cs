﻿using System;

namespace DepartmentTest
{
    public abstract class Department
    {
        public abstract string DepartmentName { get; }
        public abstract void AssignPromotion(string promotionDetails);

        public void DisplayPromotion(string promotionDetails)
        {
            Console.WriteLine($"Promotion in {DepartmentName}: {promotionDetails}");
        }
    }

    public class Fashion : Department
    {
        public override string DepartmentName => "Fashion Department";

        public override void AssignPromotion(string promotionDetails)
        {
            DisplayPromotion(promotionDetails);
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Fashion fashionDept = new Fashion();
            fashionDept.AssignPromotion("20% Calvin Klein");

        
            fashionDept.AssignPromotion("Knitted Sweaters for $35");
        }
    }
}

