﻿// See https://aka.ms/new-console-template for more information
using System;

class Program
{
    static void Main()
    {
        double number = 987654.321d;
        Console.WriteLine(Math.Round(number, 2));
        Console.WriteLine((int)number);
        Console.WriteLine("$" + Math.Round(number, 2).ToString("N2"));

        Console.ReadLine();
    }
}
